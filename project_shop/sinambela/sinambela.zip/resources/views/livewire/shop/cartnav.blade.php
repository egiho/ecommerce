<div>
    <li class="nav-item">
        <a href="{{ route('shop.cart') }}" class="nav-link">Cart ({{ $cartTotal }})</a>
    </li>
</div>
