<div>
    <li class="nav-item">
        <a href="<?php echo e(route('shop.cart')); ?>" class="nav-link">Cart (<?php echo e($cartTotal); ?>)</a>
    </li>
</div>
<?php /**PATH D:\xampp\htdocs\project_shop\sinambela\resources\views/livewire/shop/cartnav.blade.php ENDPATH**/ ?>