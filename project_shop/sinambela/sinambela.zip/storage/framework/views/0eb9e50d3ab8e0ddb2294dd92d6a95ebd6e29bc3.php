<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="form-group">
                <input wire:model="search" type="text" class="form-control" placeholder="Search Product">
            </div>
        </div>
    </div>

    <div class="row">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-12 col-xs-12 col-md-4 col-lg-3 mb-4">
            <div class="card h-80">
                <img class="card-img-top img-fluid" src="<?php echo e($product->image ? asset('/storage/' . $product->image) : 'http://placehold.it/150x150'); ?>" alt="">
                <div class="card-img-overlay" style="background-color: rgba(0,0,0,0.5);">
                    <h5 class="text-white">
                        <strong><?php echo e($product->title); ?></strong>
                    </h5>
                    <h6 class="text-white">Rp<?php echo e(number_format($product->price,2,",",".")); ?></h6>
                    <p class="text-white">
                        <?php echo e($product->description); ?>

                    </p>
                    <button wire:click="addToCart(<?php echo e($product->id); ?>)" type="button" class="btn btn-sm btn-block btn-outline-secondary text-white">Add to cart</button>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <?php echo e($products->links()); ?>

</div>
<?php /**PATH D:\xampp\htdocs\project_shop\sinambela\resources\views/livewire/shop/index.blade.php ENDPATH**/ ?>