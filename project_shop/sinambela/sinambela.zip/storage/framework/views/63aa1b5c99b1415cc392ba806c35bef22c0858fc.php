<div class="container">

    <?php if($formVisible): ?>
      <?php if(! $formUpdate): ?>
            <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('product.create')->dom;
} elseif ($_instance->childHasBeenRendered('bTHjK6p')) {
    $componentId = $_instance->getRenderedChildComponentId('bTHjK6p');
    $componentTag = $_instance->getRenderedChildComponentTagName('bTHjK6p');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bTHjK6p');
} else {
    $response = \Livewire\Livewire::mount('product.create');
    $dom = $response->dom;
    $_instance->logRenderedChild('bTHjK6p', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
      <?php else: ?>
            <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('product.update')->dom;
} elseif ($_instance->childHasBeenRendered('rnHJ1Cv')) {
    $componentId = $_instance->getRenderedChildComponentId('rnHJ1Cv');
    $componentTag = $_instance->getRenderedChildComponentTagName('rnHJ1Cv');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rnHJ1Cv');
} else {
    $response = \Livewire\Livewire::mount('product.update');
    $dom = $response->dom;
    $_instance->logRenderedChild('rnHJ1Cv', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
      <?php endif; ?>
    <?php endif; ?>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Product
                    <button wire:click="$toggle('formVisible')" class="btn btn-sm btn-primary">Create</button>
                </div>

                <div class="card-body">

                    <?php if(session()->has('message')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('message')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col">
                            <select wire:model="paginate" name="" id="" class="form-control form-control-sm w-auto">
                                <option value="5" class="value">5</option>
                                <option value="10" class="value">10</option>
                                <option value="15" class="value">15</option>
                                <option value="20" class="value">20</option>
                            </select>
                        </div>
                        <div class="col">
                            <input wire:model="search" type="" class="form-control form-control-sm" placeholder="Search">
                        </div>
                    </div>

                    <hr>

                    <table class="table">
                        <thead class="thead-dark">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Title</th>
                                <th scope="col">Price</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 0 ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $no++ ?>
                            <tr>
                                <th scope="row"><?php echo e($no); ?></th>
                                <td><?php echo e($product->title); ?></td>
                                <td>Rp<?php echo e(number_format($product->price,2,",",".")); ?></td>
                                <td>
                                    <button wire:click="editProduct(<?php echo e($product->id); ?>)" class="btn btn-sm btn-info text-white">Edit</button>
                                    <button wire:click="deleteProduct(<?php echo e($product->id); ?>)" class="btn btn-sm  btn-danger">Delete</button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\project_shop\sinambela\resources\views/livewire/product/index.blade.php ENDPATH**/ ?>